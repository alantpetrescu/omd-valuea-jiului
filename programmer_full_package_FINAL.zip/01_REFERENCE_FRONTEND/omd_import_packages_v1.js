/* OMD Valea Jiului — external JSON package importer v1
 * Browser-side staging adapter. In backend, the same contracts map to DB transactions.
 */
(function(){
  'use strict';
  const APP='OMD Valea Jiului – Sistem digital de marketing';
  const VERSION='1.0';
  const clone=value=>value===undefined?undefined:JSON.parse(JSON.stringify(value));
  const arr=value=>Array.isArray(value)?value:[];
  const resultError=(errors,warnings=[])=>({status:'error',errors:arr(errors),warnings:arr(warnings),created:{},updated:{},unchanged:{}});

  function basicValidate(pkg, type){
    const errors=[];
    if(!pkg||typeof pkg!=='object'||Array.isArray(pkg)) return {valid:false,errors:['Package-ul trebuie să fie un obiect JSON.'],warnings:[]};
    if(pkg.packageType!==type) errors.push(`packageType trebuie să fie ${type}.`);
    if(pkg.schemaVersion!==VERSION) errors.push(`schemaVersion ${String(pkg.schemaVersion||'—')} nu este compatibilă; versiunea acceptată este ${VERSION}.`);
    if(!pkg.metadata||pkg.metadata.application!==APP) errors.push('metadata.application este invalid sau lipsește.');
    if(!pkg.metadata?.packageId) errors.push('metadata.packageId lipsește.');
    return {valid:!errors.length,errors,warnings:[]};
  }

  function currentCombined(source='External package import'){
    return OMD.DataPackageService.exportPackage({source});
  }

  function combinedFrom(campaignsPackage=null, activationsPackage=null){
    const combined=currentCombined('External package adapter v1');
    combined.metadata.packageId=`adapter-${Date.now()}`;
    combined.metadata.source='External package adapter v1';
    if(campaignsPackage){
      combined.strategicData=clone(campaignsPackage.strategicData||{});
      combined.catalogs=clone(campaignsPackage.catalogs||{});
      combined.campaigns=clone(campaignsPackage.campaigns||[]);
    }
    if(activationsPackage){
      combined.activations=clone(activationsPackage.activations||[]);
      combined.annualPlans=clone(activationsPackage.annualPlans||[]);
    }
    return combined;
  }

  function validateCampaignsPackage(pkg){
    const v=basicValidate(pkg,'OMD_CAMPAIGNS_PACKAGE');
    if(!Array.isArray(pkg?.campaigns))v.errors.push('campaigns trebuie să fie array.');
    if(!pkg?.strategicData||typeof pkg.strategicData!=='object')v.errors.push('strategicData lipsește.');
    if(!pkg?.catalogs||typeof pkg.catalogs!=='object')v.errors.push('catalogs lipsește.');
    if(v.errors.length)return {...v,valid:false};
    const combined=combinedFrom(pkg,null);
    // Activările și planurile curente rămân în pachet pentru a valida referințele existente.
    const cv=OMD.DataPackageService.validatePackage(combined);
    return {valid:cv.valid,errors:cv.errors,warnings:cv.warnings};
  }

  function validateActivationsPackage(pkg, campaignsPackage=null){
    const v=basicValidate(pkg,'OMD_ACTIVATIONS_PACKAGE');
    if(!Array.isArray(pkg?.activations))v.errors.push('activations trebuie să fie array.');
    if(!Array.isArray(pkg?.annualPlans))v.errors.push('annualPlans trebuie să fie array.');
    if(v.errors.length)return {...v,valid:false};
    const combined=combinedFrom(campaignsPackage,pkg);
    const cv=OMD.DataPackageService.validatePackage(combined);
    return {valid:cv.valid,errors:cv.errors,warnings:cv.warnings};
  }

  function importCampaignsPackage(pkg,{mode='merge'}={}){
    const validation=validateCampaignsPackage(pkg);
    if(!validation.valid)return resultError(validation.errors,validation.warnings);
    const combined=combinedFrom(pkg,null);
    return OMD.DataPackageService.importPackage(combined,{mode});
  }

  function importActivationsPackage(pkg,{mode='merge'}={}){
    const validation=validateActivationsPackage(pkg,null);
    if(!validation.valid)return resultError(validation.errors,validation.warnings);
    const combined=combinedFrom(null,pkg);
    return OMD.DataPackageService.importPackage(combined,{mode});
  }

  function activationIndex(sourceActivations=null){
    const activations=sourceActivations||OMD.repositories.activation.list();
    const map=new Map();
    activations.forEach(a=>map.set(a.externalKey||a.id,a));
    return map;
  }

  function validateActivationMonitoringPackage(pkg,{sourceActivations=null}={}){
    const v=basicValidate(pkg,'OMD_ACTIVATION_MONITORING_PACKAGE');
    if(!Array.isArray(pkg?.performanceSnapshots))v.errors.push('performanceSnapshots trebuie să fie array.');
    if(v.errors.length)return {...v,valid:false};
    const acts=activationIndex(sourceActivations);
    const seen=new Set();
    arr(pkg.performanceSnapshots).forEach((s,i)=>{
      const p=`performanceSnapshots[${i}]`;
      if(!s?.externalKey)v.errors.push(`${p}.externalKey lipsește.`);
      else if(seen.has(s.externalKey))v.errors.push(`${p}.externalKey duplicat: ${s.externalKey}.`); else seen.add(s.externalKey);
      const activation=acts.get(s?.activationExternalKey);
      if(!activation){v.errors.push(`${p}.activationExternalKey nu există: ${String(s?.activationExternalKey||'—')}.`);return;}
      const material=arr(activation.materials).find(m=>(m.externalKey||m.id)===s?.materialExternalKey);
      if(!material)v.errors.push(`${p}.materialExternalKey nu există în activare: ${String(s?.materialExternalKey||'—')}.`);
      if(!s?.metrics||typeof s.metrics!=='object')v.errors.push(`${p}.metrics lipsește.`);
    });
    return {valid:!v.errors.length,errors:v.errors,warnings:v.warnings};
  }

  function snapshotToApiResults(snapshot){
    const m=snapshot.metrics||{};
    return {
      clicks:m.clicks??null,
      comments:m.comments??null,
      impressions:m.impressions??null,
      reach:m.reach??null,
      reactions:m.reactions??null,
      saves:m.saves??null,
      shares:m.shares??null,
      source:snapshot.provider?.label||snapshot.provider?.code||'',
      spend:m.spend??null,
      updatedAt:snapshot.observedAt||'',
      views:m.views??null
    };
  }

  function importActivationMonitoringPackage(pkg){
    const validation=validateActivationMonitoringPackage(pkg);
    if(!validation.valid)return resultError(validation.errors,validation.warnings);
    const before=[];
    try{
      arr(pkg.performanceSnapshots).forEach(snapshot=>{
        const activation=OMD.repositories.activation.get(snapshot.activationExternalKey);
        const material=arr(activation.materials).find(m=>(m.externalKey||m.id)===snapshot.materialExternalKey);
        before.push({activationId:activation.id,materialId:material.id,apiResults:clone(material.apiResults??null)});
      });
      arr(pkg.performanceSnapshots).forEach(snapshot=>{
        OMD.repositories.monitoring.save({
          activationId:snapshot.activationExternalKey,
          materialId:snapshot.materialExternalKey,
          apiResults:snapshotToApiResults(snapshot)
        });
      });
      return {status:'success',errors:[],warnings:validation.warnings,imported:pkg.performanceSnapshots.length,packageId:pkg.metadata.packageId};
    }catch(error){
      before.forEach(row=>{
        try{OMD.repositories.monitoring.save({activationId:row.activationId,materialId:row.materialId,apiResults:row.apiResults});}catch{}
      });
      return {status:'error',errors:[String(error?.message||error)],warnings:validation.warnings,rolledBack:true,imported:0};
    }
  }

  function validateReputationMonitoringPackage(pkg){
    const v=basicValidate(pkg,'OMD_REPUTATION_MONITORING_PACKAGE');
    if(!Array.isArray(pkg?.reputationSnapshots))v.errors.push('reputationSnapshots trebuie să fie array.');
    const seen=new Set();
    arr(pkg?.reputationSnapshots).forEach((s,i)=>{
      const p=`reputationSnapshots[${i}]`;
      if(!s?.externalKey)v.errors.push(`${p}.externalKey lipsește.`);
      else if(seen.has(s.externalKey))v.errors.push(`${p}.externalKey duplicat: ${s.externalKey}.`); else seen.add(s.externalKey);
      if(!s?.metrics||typeof s.metrics!=='object')v.errors.push(`${p}.metrics lipsește.`);
    });
    return {valid:!v.errors.length,errors:v.errors,warnings:v.warnings};
  }

  function reputationSnapshotToRuntime(snapshot){
    const metrics=snapshot.metrics||{};
    const values={
      mentions:metrics.mentionsCount??0,
      positive:metrics.positiveSharePct??0,
      reviews:metrics.reviewsCount??0,
      score:metrics.averageRating==null?'—':Number(metrics.averageRating).toFixed(2).replace('.',',')
    };
    const chooseValue=item=>item?.score??item?.sharePct??item?.mentionsCount??item?.reviewsCount??0;
    return {
      unloaded:clone(values),
      loaded:clone(values),
      themes:arr(snapshot.themes).map(item=>[item.label||item.code||'',chooseValue(item)]),
      sources:arr(snapshot.sources).map(item=>[item.label||item.code||'',chooseValue(item)]),
      observedAt:snapshot.observedAt||'',
      externalKey:snapshot.externalKey||'',
      provider:clone(snapshot.provider||{}),
      rawSnapshot:clone(snapshot)
    };
  }

  function importReputationMonitoringPackage(pkg){
    const validation=validateReputationMonitoringPackage(pkg);
    if(!validation.valid)return resultError(validation.errors,validation.warnings);
    const snapshots=arr(pkg.reputationSnapshots).slice().sort((a,b)=>String(a.observedAt||'').localeCompare(String(b.observedAt||'')));
    if(!snapshots.length){
      OMD.repositories.monitoring.saveReputationData?.({unloaded:{mentions:0,positive:0,reviews:0,score:'—'},loaded:{mentions:0,positive:0,reviews:0,score:'—'},themes:[],sources:[]});
      return {status:'success',errors:[],warnings:[],imported:0,packageId:pkg.metadata.packageId};
    }
    const runtime=reputationSnapshotToRuntime(snapshots.at(-1));
    if(typeof OMD.repositories.monitoring.saveReputationData!=='function')return resultError(['MonitoringRepository nu expune saveReputationData().']);
    OMD.repositories.monitoring.saveReputationData(runtime);
    return {status:'success',errors:[],warnings:validation.warnings,imported:snapshots.length,latestObservedAt:snapshots.at(-1).observedAt,packageId:pkg.metadata.packageId};
  }

  function importDemoBundle({campaigns,activations,activationMonitoring,reputationMonitoring},{mode='replace'}={}){
    const vc=validateCampaignsPackage(campaigns); if(!vc.valid)return {status:'error',stage:'campaigns-validation',errors:vc.errors,warnings:vc.warnings};
    const va=validateActivationsPackage(activations,campaigns); if(!va.valid)return {status:'error',stage:'activations-validation',errors:va.errors,warnings:va.warnings};
    const vm=validateActivationMonitoringPackage(activationMonitoring,{sourceActivations:activations.activations}); if(!vm.valid)return {status:'error',stage:'activation-monitoring-validation',errors:vm.errors,warnings:vm.warnings};
    const vr=validateReputationMonitoringPackage(reputationMonitoring); if(!vr.valid)return {status:'error',stage:'reputation-validation',errors:vr.errors,warnings:vr.warnings};

    const combined=combinedFrom(campaigns,activations);
    const core=OMD.DataPackageService.importPackage(combined,{mode});
    if(core.status!=='success')return {status:'error',stage:'core-import',errors:core.errors||[],core};
    const performance=importActivationMonitoringPackage(activationMonitoring);
    if(performance.status!=='success')return {status:'error',stage:'activation-monitoring-import',errors:performance.errors||[],core,performance};
    const reputation=importReputationMonitoringPackage(reputationMonitoring);
    if(reputation.status!=='success')return {status:'error',stage:'reputation-import',errors:reputation.errors||[],core,performance,reputation};
    return {status:'success',core,performance,reputation};
  }

  async function fetchJson(url){
    const response=await fetch(url,{cache:'no-store'});
    if(!response.ok)throw new Error(`${url}: HTTP ${response.status}`);
    return response.json();
  }

  const DEFAULT_FILES=Object.freeze({
    campaigns:'OMD_CAMPAIGNS_PACKAGE_DEMO_SEED_v1.json',
    activations:'OMD_ACTIVATIONS_PACKAGE_DEMO_SEED_v1.json',
    activationMonitoring:'OMD_ACTIVATION_MONITORING_PACKAGE_DEMO_SEED_v1.json',
    reputationMonitoring:'OMD_REPUTATION_MONITORING_PACKAGE_DEMO_SEED_v1.json'
  });

  async function loadDemoBundle(files=DEFAULT_FILES){
    const [campaigns,activations,activationMonitoring,reputationMonitoring]=await Promise.all([
      fetchJson(files.campaigns),fetchJson(files.activations),fetchJson(files.activationMonitoring),fetchJson(files.reputationMonitoring)
    ]);
    return {campaigns,activations,activationMonitoring,reputationMonitoring};
  }

  async function autoSeedDemo(){
    const cfg=window.OMD_EXTERNAL_DATA_CONFIG||{};
    if(cfg.autoSeed===false)return {status:'skipped',reason:'disabled'};
    const existingCampaigns=OMD.repositories.campaign.list().length;
    const existingActivations=OMD.repositories.activation.list().length;
    if(!cfg.forceSeed&&(existingCampaigns||existingActivations))return {status:'skipped',reason:'data-exists',existingCampaigns,existingActivations};
    try{
      const bundle=await loadDemoBundle(cfg.files||DEFAULT_FILES);
      const report=importDemoBundle(bundle,{mode:'replace'});
      window.OMD_EXTERNAL_IMPORT_REPORT=report;
      if(report.status==='success'){
        OMD.app?.navigate?.(OMD.app.current||'campaigns');
        OMD.toast?.(`Date externe încărcate: ${OMD.repositories.campaign.list().length} campanii, ${OMD.repositories.activation.list().length} activări.`);
      }else OMD.toast?.(`Importul datelor externe a eșuat la etapa ${report.stage||'necunoscută'}.`);
      return report;
    }catch(error){
      const report={status:'error',stage:'fetch',errors:[String(error?.message||error)]};
      window.OMD_EXTERNAL_IMPORT_REPORT=report;
      OMD.toast?.('Fișierele JSON externe nu au putut fi încărcate. Rulează HTML-ul printr-un server HTTP local sau de staging.');
      return report;
    }
  }

  window.OMD=window.OMD||{};
  OMD.ExternalPackageImporter={
    VERSION,DEFAULT_FILES,basicValidate,
    validateCampaignsPackage,validateActivationsPackage,validateActivationMonitoringPackage,validateReputationMonitoringPackage,
    importCampaignsPackage,importActivationsPackage,importActivationMonitoringPackage,importReputationMonitoringPackage,
    importDemoBundle,loadDemoBundle,autoSeedDemo
  };

  document.addEventListener('DOMContentLoaded',()=>setTimeout(()=>autoSeedDemo(),0));
})();
