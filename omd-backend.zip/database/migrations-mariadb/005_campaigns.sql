-- GENERAT AUTOMAT — nu edita acest fișier.
--
-- Sursa: database/migrations/005_campaigns.sql
-- Comanda: php bin/generate-mariadb-migrations.php
--
-- Singura diferență față de sursă este colația: MySQL 8 folosește
-- `utf8mb4_0900_ai_ci`, care nu există în MariaDB. Echivalentul cel mai apropiat
-- disponibil acolo este `utf8mb4_unicode_520_nopad_ci` — aceeași insensibilitate la diacritice
-- și la majuscule, același tratament NO PAD al spațiilor finale.
--
-- Motivul alegerii e explicat în src/Database/Dialect.php.

-- OMD Valea Jiului migration: Campaigns and their relation tables
-- Generated verbatim from 02_DATABASE/MYSQL_SCHEMA_BLUEPRINT.sql
-- (sha256 d76b645f05c47707e9edba44cf922dad36b95341ea2b22ea59969c3f402978f4).
-- Do not edit in place: schema changes go into a new numbered migration.

CREATE TABLE campaigns (
  id CHAR(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  external_key VARCHAR(191) NOT NULL,
  campaign_family_external_key VARCHAR(191) NOT NULL,
  supersedes_campaign_id CHAR(36) CHARACTER SET ascii COLLATE ascii_general_ci NULL,
  strategy_version_id CHAR(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  title VARCHAR(500) NOT NULL,
  accent VARCHAR(64) NOT NULL,
  campaign_type_id CHAR(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  status_id CHAR(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  parent_campaign_id CHAR(36) CHARACTER SET ascii COLLATE ascii_general_ci NULL,
  pillar_id CHAR(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  seasonality_type_id CHAR(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  seasonality_months JSON NOT NULL,
  seasonality_note TEXT NOT NULL,
  version_label VARCHAR(255) NOT NULL,
  responsible VARCHAR(255) NOT NULL,
  marketing_objective TEXT NOT NULL,
  direct_result TEXT NOT NULL,
  strategic_contribution JSON NOT NULL,
  primary_audience_description TEXT NOT NULL,
  central_idea TEXT NOT NULL,
  promise TEXT NOT NULL,
  main_message TEXT NOT NULL,
  secondary_messages JSON NOT NULL,
  tone TEXT NOT NULL,
  insight TEXT NOT NULL,
  value_proposition TEXT NOT NULL,
  products JSON NOT NULL,
  products_intro TEXT NOT NULL,
  product_condition TEXT NOT NULL,
  channels JSON NOT NULL,
  pr_partnerships TEXT NOT NULL,
  storytelling_directions JSON NOT NULL,
  fixed_elements JSON NOT NULL,
  adaptable_elements JSON NOT NULL,
  adaptation_limits JSON NOT NULL,
  framework_deliverables JSON NOT NULL,
  deliverable_intro TEXT NOT NULL,
  posts JSON NOT NULL,
  headlines JSON NOT NULL,
  video_concepts JSON NOT NULL,
  application_examples JSON NOT NULL,
  kpi_definitions JSON NOT NULL,
  activation_examples JSON NOT NULL,
  no_visuals_note TEXT NOT NULL,
  source_file VARCHAR(255) NOT NULL,
  source_created_at_raw VARCHAR(64) NOT NULL,
  source_updated_at_raw VARCHAR(64) NOT NULL,
  version_number INT UNSIGNED NOT NULL DEFAULT 1,
  created_by CHAR(36) CHARACTER SET ascii COLLATE ascii_general_ci NULL,
  updated_by CHAR(36) CHARACTER SET ascii COLLATE ascii_general_ci NULL,
  deleted_by CHAR(36) CHARACTER SET ascii COLLATE ascii_general_ci NULL,
  created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  deleted_at DATETIME(6) NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_campaigns_external_key (external_key),
  UNIQUE KEY uq_campaigns_family_strategy (campaign_family_external_key, strategy_version_id),
  KEY idx_campaigns_family (campaign_family_external_key, deleted_at),
  KEY idx_campaigns_supersedes (supersedes_campaign_id),
  KEY idx_campaigns_strategy_version (strategy_version_id, deleted_at),
  KEY idx_campaigns_status (status_id, deleted_at),
  KEY idx_campaigns_type (campaign_type_id, deleted_at),
  KEY idx_campaigns_pillar (pillar_id, deleted_at),
  KEY idx_campaigns_parent (parent_campaign_id),
  KEY idx_campaigns_seasonality (seasonality_type_id),
  CONSTRAINT fk_campaigns_supersedes FOREIGN KEY (supersedes_campaign_id) REFERENCES campaigns(id) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT fk_campaigns_strategy_version FOREIGN KEY (strategy_version_id) REFERENCES strategy_versions(id) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT fk_campaigns_type FOREIGN KEY (campaign_type_id) REFERENCES campaign_types(id) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT fk_campaigns_status FOREIGN KEY (status_id) REFERENCES campaign_statuses(id) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT fk_campaigns_parent FOREIGN KEY (parent_campaign_id) REFERENCES campaigns(id) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT fk_campaigns_pillar FOREIGN KEY (pillar_id) REFERENCES strategic_pillars(id) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT fk_campaigns_seasonality FOREIGN KEY (seasonality_type_id) REFERENCES seasonality_types(id) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT fk_campaigns_created_by FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL ON UPDATE RESTRICT,
  CONSTRAINT fk_campaigns_updated_by FOREIGN KEY (updated_by) REFERENCES users(id) ON DELETE SET NULL ON UPDATE RESTRICT,
  CONSTRAINT fk_campaigns_deleted_by FOREIGN KEY (deleted_by) REFERENCES users(id) ON DELETE SET NULL ON UPDATE RESTRICT,
  CONSTRAINT chk_campaigns_not_self_supersede CHECK (supersedes_campaign_id IS NULL OR supersedes_campaign_id <> id),
  CONSTRAINT chk_campaign_version CHECK (version_number >= 1),
  CONSTRAINT chk_campaign_months_json CHECK (JSON_TYPE(seasonality_months) = 'ARRAY'),
  CONSTRAINT chk_campaign_strategic_json CHECK (JSON_TYPE(strategic_contribution) = 'ARRAY'),
  CONSTRAINT chk_campaign_secondary_messages_json CHECK (JSON_TYPE(secondary_messages) = 'ARRAY'),
  CONSTRAINT chk_campaign_products_json CHECK (JSON_TYPE(products) = 'ARRAY'),
  CONSTRAINT chk_campaign_channels_json CHECK (JSON_TYPE(channels) = 'ARRAY'),
  CONSTRAINT chk_campaign_storytelling_json CHECK (JSON_TYPE(storytelling_directions) = 'ARRAY'),
  CONSTRAINT chk_campaign_fixed_json CHECK (JSON_TYPE(fixed_elements) = 'ARRAY'),
  CONSTRAINT chk_campaign_adaptable_json CHECK (JSON_TYPE(adaptable_elements) = 'ARRAY'),
  CONSTRAINT chk_campaign_limits_json CHECK (JSON_TYPE(adaptation_limits) = 'ARRAY'),
  CONSTRAINT chk_campaign_framework_json CHECK (JSON_TYPE(framework_deliverables) = 'ARRAY'),
  CONSTRAINT chk_campaign_posts_json CHECK (JSON_TYPE(posts) = 'ARRAY'),
  CONSTRAINT chk_campaign_headlines_json CHECK (JSON_TYPE(headlines) = 'ARRAY'),
  CONSTRAINT chk_campaign_video_json CHECK (JSON_TYPE(video_concepts) = 'ARRAY'),
  CONSTRAINT chk_campaign_examples_json CHECK (JSON_TYPE(application_examples) = 'ARRAY'),
  CONSTRAINT chk_campaign_kpis_json CHECK (JSON_TYPE(kpi_definitions) = 'ARRAY'),
  CONSTRAINT chk_campaign_activation_examples_json CHECK (JSON_TYPE(activation_examples) = 'OBJECT')
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_nopad_ci;

CREATE TABLE campaign_programs (
  campaign_id CHAR(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  program_id CHAR(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  relation_role VARCHAR(16) NOT NULL,
  sort_order INT UNSIGNED NOT NULL DEFAULT 0,
  created_by CHAR(36) CHARACTER SET ascii COLLATE ascii_general_ci NULL,
  created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (campaign_id, program_id),
  KEY idx_campaign_programs_program (program_id),
  CONSTRAINT fk_campaign_programs_campaign FOREIGN KEY (campaign_id) REFERENCES campaigns(id) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT fk_campaign_programs_program FOREIGN KEY (program_id) REFERENCES strategic_programs(id) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT fk_campaign_programs_created_by FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL ON UPDATE RESTRICT,
  CONSTRAINT chk_campaign_program_role CHECK (relation_role IN ('PRIMARY','SECONDARY'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_nopad_ci;

CREATE TABLE campaign_objectives (
  campaign_id CHAR(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  objective_id CHAR(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  relation_role VARCHAR(16) NOT NULL,
  sort_order INT UNSIGNED NOT NULL DEFAULT 0,
  created_by CHAR(36) CHARACTER SET ascii COLLATE ascii_general_ci NULL,
  created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (campaign_id, objective_id),
  KEY idx_campaign_objectives_objective (objective_id),
  CONSTRAINT fk_campaign_objectives_campaign FOREIGN KEY (campaign_id) REFERENCES campaigns(id) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT fk_campaign_objectives_objective FOREIGN KEY (objective_id) REFERENCES strategic_objectives(id) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT fk_campaign_objectives_created_by FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL ON UPDATE RESTRICT,
  CONSTRAINT chk_campaign_objective_role CHECK (relation_role IN ('PRIMARY','SECONDARY'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_nopad_ci;

CREATE TABLE campaign_audiences (
  campaign_id CHAR(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  audience_segment_id CHAR(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  relation_role VARCHAR(16) NOT NULL,
  sort_order INT UNSIGNED NOT NULL DEFAULT 0,
  created_by CHAR(36) CHARACTER SET ascii COLLATE ascii_general_ci NULL,
  created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (campaign_id, audience_segment_id),
  KEY idx_campaign_audiences_segment (audience_segment_id),
  CONSTRAINT fk_campaign_audiences_campaign FOREIGN KEY (campaign_id) REFERENCES campaigns(id) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT fk_campaign_audiences_segment FOREIGN KEY (audience_segment_id) REFERENCES audience_segments(id) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT fk_campaign_audiences_created_by FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL ON UPDATE RESTRICT,
  CONSTRAINT chk_campaign_audience_role CHECK (relation_role IN ('PRIMARY','SECONDARY'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_nopad_ci;

CREATE TABLE campaign_ctas (
  campaign_id CHAR(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  cta_type_id CHAR(36) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  sort_order INT UNSIGNED NOT NULL DEFAULT 0,
  created_by CHAR(36) CHARACTER SET ascii COLLATE ascii_general_ci NULL,
  created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (campaign_id, cta_type_id),
  KEY idx_campaign_ctas_cta (cta_type_id),
  CONSTRAINT fk_campaign_ctas_campaign FOREIGN KEY (campaign_id) REFERENCES campaigns(id) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT fk_campaign_ctas_type FOREIGN KEY (cta_type_id) REFERENCES cta_types(id) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT fk_campaign_ctas_created_by FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_nopad_ci;
